package com.thoughtworks.wugui;

public enum Color {
    RED,GREEN,BLACK,WHITE
}

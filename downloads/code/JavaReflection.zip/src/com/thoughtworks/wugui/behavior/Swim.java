package com.thoughtworks.wugui.behavior;

public interface Swim {
    void swim();
}

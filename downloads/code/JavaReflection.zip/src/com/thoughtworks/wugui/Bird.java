package com.thoughtworks.wugui;

import com.thoughtworks.wugui.behavior.Shout;

public abstract class Bird implements Shout {
}

package com.thoughtworks.wugui;

import com.thoughtworks.wugui.behavior.Swim;

public class Penguin extends Bird implements Swim {
    public String name;
    private Color color;



    public Penguin(String name) {
        this.name = name;
    }

    public Penguin(Color color) {
        this.color = color;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void swim() {
        System.out.println("I like swim!");
    }

    public String shout(int times) {
        StringBuilder sb = new StringBuilder();
        for(int i = 0;i<times;i++){
            sb.append("yell..");
        }
        return sb.toString();
    }
}

package com.thoughtworks.wugui;

import com.thoughtworks.wugui.behavior.Swim;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static junit.framework.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

    public class Zoo {
        private Class penguinClass;
        private Class birdClass;

        @Before
        public void setUp() {
            //编译期
            penguinClass = Penguin.class;
            birdClass = Bird.class;
        }

    @Test
    public void how_to_get_class_and_className() throws ClassNotFoundException {
        //运行期
        String penguinClassName = "com.thoughtworks.wugui.Penguin";
        Class clazz = Class.forName(penguinClassName);

        assertSame(clazz, penguinClass);
        assertThat(clazz.getSimpleName(), is("Penguin"));
    }

    @Test
    public void how_to_get_modifiers() throws Exception {
        int modifier = birdClass.getModifiers();
        assertTrue(Modifier.isAbstract(modifier));
        assertTrue(Modifier.isPublic(modifier));
    }

    @Test
    public void how_to_get_package() {
        int modifier = birdClass.getModifiers();

        assertThat(birdClass.getPackage().getName(), is("com.thoughtworks.wugui"));
    }

    @Test
    public void how_to_get_superclass() throws Exception {
        assertSame(penguinClass.getSuperclass(), birdClass);
    }

    @Test
    public void how_to_get_interfaces() throws Exception {
        Class[] interfaces = penguinClass.getInterfaces();

        assertThat(interfaces.length, is(1));
        assertSame(interfaces[0], Swim.class);
        //Actually penguin implement two interfaces, swim and shout. So the getInterface method
        //just return declared interfaces above the class
    }

    //Constructor
    @Test
    public void how_to_get_constructors() throws Exception {
        Constructor[] constructors = penguinClass.getConstructors();

        assertThat(constructors.length, is(2));
    }

    @Test
    public void get_constructor_through_parameters() throws Exception {
        Constructor constructor = penguinClass.getConstructor(new Class[]{Color.class});

        assertThat(constructor, notNullValue());
    }

    @Test
    public void get_parameters_from_constructor() throws NoSuchMethodException {
        Constructor constructor = penguinClass.getConstructor(new Class[]{Color.class});

        Class[] parameterTypes = constructor.getParameterTypes();

        assertSame(parameterTypes[0], Color.class);
    }

    @Test
    public void create_instance_using_constructor() throws Exception {
        Constructor constructor = penguinClass.getConstructor(new Class[]{Color.class});

        Penguin penguin = (Penguin) constructor.newInstance(Color.WHITE);

        assertThat(penguin.getColor(), is(Color.WHITE));
    }

    //Field It can only get the public field, if the field is private, you can only
    //operate the field by get/set method

    @Test
    public void how_to_get_fields_from_class() throws NoSuchFieldException {
        Field[] fields = penguinClass.getFields();

        assertThat(fields.length, is(1));

        Field name = penguinClass.getField("name");

        assertThat(name.getName(), is("name"));

        assertSame(name.getType(), String.class);
    }

    @Test
    public void get_and_set_field_value() throws Exception {
        Field name = penguinClass.getField("name");
        Penguin penguin = new Penguin("emperor penguin");

        assertThat((String) name.get(penguin), is("emperor penguin"));

        name.set(penguin, "fairy penguin");

        assertThat(penguin.getName(), is("fairy penguin"));
    }

    //Method
    @Test
    public void get_and_methods_from_class() throws NoSuchMethodException {
        //The Method[] array will have one Method instance for each public method declared in the class.
        Method[] methods = penguinClass.getMethods();

        //get a specific method, if no parameters, just pass null
        Method swimMethod = penguinClass.getMethod("swim", null);
        Method shoutMethod = penguinClass.getMethod("shout", new Class[]{int.class});

        Class[] parameterTypes = shoutMethod.getParameterTypes();
        assertSame(parameterTypes[0], int.class);

        Class returnType = shoutMethod.getReturnType();
        assertSame(returnType, String.class);

    }

    @Test
    public void invoke_method_from_class() throws Exception {
        Penguin penguin = mock(Penguin.class);

        Method swimMethod = penguinClass.getMethod("swim", null);
        Method shoutMethod = penguinClass.getMethod("shout", new Class[]{int.class});

        swimMethod.invoke(penguin, null);
        verify(penguin, times(1)).swim();

        shoutMethod.invoke(penguin, 2);
        verify(penguin, times(1)).shout(2);
    }

    //getter and setter

    @Test
    public void getter_and_setter() {
        //java doesn't have internal method to get getter and setter, so we need to use some custom
        //method to get the getter and setter
        Method[] methods = penguinClass.getMethods();

        for(Method method : methods){
            if(isGetter(method)) System.out.println("getter: " + method);
            if(isSetter(method)) System.out.println("setter: " + method);
        }
    }

    private boolean isGetter(Method method) {
        if (!method.getName().startsWith("get")) return false;
        if (method.getParameterTypes().length != 0) return false;
        if (void.class.equals(method.getReturnType())) return false;
        return true;
    }

    public boolean isSetter(Method method) {
        if (!method.getName().startsWith("set")) return false;
        if (method.getParameterTypes().length != 1) return false;
        return true;
    }


}

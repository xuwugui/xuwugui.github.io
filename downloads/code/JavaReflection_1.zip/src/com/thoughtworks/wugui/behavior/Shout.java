package com.thoughtworks.wugui.behavior;

public interface Shout {
    String shout(int times);
}
